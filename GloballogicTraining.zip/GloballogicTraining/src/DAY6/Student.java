package DAY6;

 public class Student {

		    int rollno,m1,m2;
		    float avg;
		   public String name;
		  
		  public void average()
		  {
			  avg=(m1+m2)/2;
			 
		 }
		  
		  public Student(int rollno,int m1,int m2,String name)
		  { 
			  this.rollno=rollno;
			  this.m1=m1;
			  this.m2=m2;
			  this.name=name;
			  average();
			  
	    }
		  
		  public void display()
		  {
			  System.out.println("Roll No:"+rollno);
			  System.out.println("Name:"+name);
			  System.out.println("Marks1:"+m1);
			  System.out.println("Marks2:"+m2);
			  System.out.println("Average:"+avg);
			  System.out.println("\n");
			  
			  
		  }
			
}
