package DAY6;

public class pgm1 {
	public static void main(String[] args) {
		
		String[] names= {"Pratik","Guarav","Prakash","Kapoor"};
		for(String name:names)
	     System.out.println(name);
		}
	}


