package DAY6;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		ArrayList<String> arr=new ArrayList<String>();
		arr.add("Pratik");
		arr.add("Rupam");
		arr.add("Ganesh");
		arr.add("Shobha");
		arr.add("Mahesh");
		arr.add("Shambhu");
		System.out.println("Before Deletion:"+arr);
		
		arr.remove(3);
		System.out.println("After Deletion:"+arr);
		
		arr.add(3,"Saket");
		System.out.println("After Addition at index 3:"+arr);
		
		 
		

	}

}
