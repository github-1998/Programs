package DAY6;

import java.util.ArrayList;

public class pgm3 {
	
	static ArrayList<Student> student= new ArrayList<Student>();
	
	public static void create()
	{
		
		Student s1=new Student(301,80,90,"Ramesh");
		Student s2=new Student(302,90,100,"Pratik");
		student.add(s1);
		student.add(s2);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		create();
		
		
		for(Student s:student)
			s.display();
		
	
		
		
	}

}
