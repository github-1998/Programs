package DAY6;

public class tiger extends animal {
	
	 
	
	public void roar() {
		System.out.println("Tiger Roars");
	}
	

	public void climb() {
		System.out.println("Tiger climbs tree");
	}
	
	public void hunts() {
		System.out.println("Tiger hunts its prey");
	}
	
		
		
	public tiger(int age,String color,String food,String gender,String name) {
		 
		this.age=age;
		this.color=color;
	    this.food=food;
	    this.gender=gender;
		this.name=name;
		
		
		 
	}


	public void display() {
		
		
		 
		System.out.println("Properties of Tiger:");
		System.out.println("Color:"+color);
		System.out.println("Food:"+food);
		System.out.println("Gender:"+gender);
		System.out.println("Name:"+name);
		
	    System.out.println("Behaviours of Tiger:");
	    this.walks();
	    this.eats();
	    this.runs();
	    this.roar();
	    this.climb();
	    this.hunts();
		 
	}

}
 


