 

package DAY6;
import DAY6.elephant;
import DAY6.tiger;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		elephant e1 = new elephant(28,"Black","Tree bark","male","Airavat");
		elephant e2 = new elephant(33,"Black","Leaves","male","Nathuraman");
		tiger t1 = new tiger(24,"dark-black","Deer","male","Bengal Nawab");
		tiger t2 = new tiger(24,"white","Deer","male","Mysore raja");
		
		 
		e1.display();
		e1.eats();
		e1.swim();
		
		


		e2.display();
		e2.eats();
		e2.swim();
		//e2.runs();
		//e2.acts();
		
		 
		t1.climb();
		t1.eats();
		t1.roar();
		t1.runs();
		
		 
		t2.climb();
		t2.eats();
		t2.roar();
		t2.runs();
		

	}

}
  
