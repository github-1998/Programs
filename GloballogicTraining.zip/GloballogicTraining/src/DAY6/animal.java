package DAY6;

public class animal {
	 
    int nol;
	String color;
	String food;
	String name;
	String gender;
	int age;
	
	
	public void walks() {
		System.out.println("the animal walks\n");
	}
	
	public void eats() {
		System.out.println("the animal eats\n");
	}
	
	public void runs() {
		System.out.println("the animal runs\n");
	}
	
	
	
	 
	
}
 


