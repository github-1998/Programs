package DAY6;

public class elephant extends animal{
	
	
	
	
	public elephant(int age,String color,String food,String gender,String name) {
		// TODO Auto-generated constructor stub
		 
		this.age=age;
		this.color=color;
		this.food=food;
		this.gender=gender;
		this.name=name;
		
		}

		 
		
	 


		public void swim() {
			System.out.println("Elephant swims");
		}
		

		public void spraying() {
			System.out.println("Elephant sprays using trunks");
		}
		public void acts() {
			System.out.println("This Elephant acts");
		}
		
			
		

	 


		public void display() {
			 
			System.out.println("Details of Elephant:");
			System.out.println("Color:"+color);
			System.out.println("Food:"+food);
			System.out.println("Gender:"+gender);
			System.out.println("Name:"+name);
			
			System.out.println("Details of Elephant:");
			this.walks();
		    this.eats();
		    this.runs();
		    this.swim();
		    this.spraying();
		    this.acts();
			
			
		}
}
 


