package DAY5;

import DAY3.Student;

public class excel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    int i;
		
	  ExcelFile ex=new ExcelFile();
		for(i=1;i<=2;i++) {
		Student s=new Student();
		s=ex.read_excel(s,i);
		s.average();
		ex.write_excel(s,i);
		 

	}
}
}

