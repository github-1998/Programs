package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import DAY3.Student;

public class ExcelFile {
	
	 public Student read_excel(Student s,int row)
		{
		
	 
		 try {
				
			    File f=new File("C:\\Users\\pratik.kumar2\\Desktop\\Book2.xlsx");
				FileInputStream fis=new FileInputStream(f);
				@SuppressWarnings("resource")
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				
				 
					  
			      
				XSSFRow r1=sh.getRow(row);
				
				XSSFCell c0=r1.getCell(0);
				s.rollno =(int)c0.getNumericCellValue();
				
			    XSSFCell c1=r1.getCell(1);
				s.name=c1.getStringCellValue();
				
				XSSFCell c2=r1.getCell(2);
				s.m1=(int)c2.getNumericCellValue();
				
				XSSFCell c3=r1.getCell(3);
				s.m2=(int)c3.getNumericCellValue();
				
			 
				

			}
			
			
		catch(FileNotFoundException e) {
			e.printStackTrace();
			}
			
			catch(IOException e) {
				e.printStackTrace();
			}
			
			return s;
			
		}
	 
	 
	 

		
		
		public void write_excel(Student s,int row)
		{
             try {
				
				File f=new File("C:\\Users\\pratik.kumar2\\Desktop\\Book2.xlsx");
				FileInputStream fis=new FileInputStream(f);
				@SuppressWarnings("resource")
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow r=sh.getRow(row);
				XSSFCell c=r.createCell(4);
				
				c.setCellValue(s.avg);
				
				FileOutputStream fos=new FileOutputStream(f);
				wb.write(fos);
				 
				 
				 }
             
             
		catch(FileNotFoundException e1) {
			e1.printStackTrace();
			}
			
			catch(IOException e) {
				e.printStackTrace();
			} 
			
		}
}
