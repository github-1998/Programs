package DAY5;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		try {
			int n=10,m=0,p;
			p=n/m;
			System.out.print(p);
			
			
			int a[]= {1,2,3};
			System.out.print(a[3]);
			
			
			
		}
		
		catch(ArithmeticException e)
		{
		System.out.print("Arithmetic  Exception Handled");
			
		}
		
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.print("Array index out of bounds exception handled");
			
		}
		
		
		
		
		

	}

}
