package DAY4;

import java.util.ArrayList;

//import com.sun.glass.ui.Size;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

     String s = "   hello   world   how are   you   ";
		 ArrayList<String> words=new ArrayList<String>();
		 char[] myString=s.toCharArray();
		 char[] word=new char[50];
		
		int i;
		int j=0;
		
		for (i=0;i<myString.length;i++) 
		{                  
		       
			//if(myString[i]==' ')
				//continue;
			
		   
			if(myString[i]!=' ')
		   {
			 word[j]=myString[i];
		    j++;
		   }
		   
		   
		   else 
		   {
			   //String str=new String(word);
			   //if(myString[i]!=' ') {}
			  // words.add(new String(word));
			   
			   //else
				   System.out.println(word);
		       word=new char[50];
		       j=0;
		   }
	}
		
		for(String w:words)
			System.out.println(w);
		
		
		
	}  
	
}
	
	

