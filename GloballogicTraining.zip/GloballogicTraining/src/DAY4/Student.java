package DAY4;

public class Student {
	
	
	
	int rollno;
	String name;
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
