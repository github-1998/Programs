package DAY4;

public class Calculate {
	
	
	public int add(int x,int y) {
		
		return x+y;
	
	}
	
	
	
	public int add(int x,int y,int z)
	{
		
		return x+y+z;
	}

	
	
}
