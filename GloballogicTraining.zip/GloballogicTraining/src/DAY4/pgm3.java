package DAY4;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int r,c,cmax,dmax,d;
		cmax=3;
		dmax=1;
		
		for(r=1;r<=4;r++)
		{
			
			for(c=1;c<=cmax;c++)
			  System.out.print("#");
			
			
			
			for(d=1;d<=dmax;d++)
			{
				if(d==1)
					System.out.print("1");
				else
				System.out.print("#1");
			}
			
			System.out.println();
			cmax-=1;
			dmax+=1;
		}
		
	}

}
