package DAY4;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int r,c,cmax,dmax,d;
		cmax=4;
		dmax=1;
		
		for(r=1;r<=3;r++)
		{
			
			for(c=1;c<=cmax;c++)
			  System.out.print("#");
			
			
			
			for(d=1;d<=dmax;d++)
			{
				if(d==dmax)
					System.out.print("1");
				else
				System.out.print("1#");
			}
			
			System.out.println();
			cmax-=2;
			dmax+=1;
		}
		
	}

}
