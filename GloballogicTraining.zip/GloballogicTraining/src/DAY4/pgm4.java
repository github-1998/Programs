package DAY4;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=20,y=30,z=45;
		//x=20,y=30,z=45;
		Calculate c=new Calculate();
		System.out.println(c.add(x,y));
		System.out.println(c.add(x,y,z));
		
		
		
		

	}

}
