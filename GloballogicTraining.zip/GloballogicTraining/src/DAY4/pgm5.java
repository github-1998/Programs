package DAY4;

import java.util.Hashtable;

public class pgm5 {

	public static void main(String[] args) {
		 
		String str="Hi guys";
		char s[]=str.toCharArray();
		Hashtable<Character,Integer> charCount=new Hashtable<Character,Integer>();
		for(char c:s)
		{ 
			 
			  if(charCount.containsKey(c))
			   charCount.put(c,charCount.get(c)+1);
			  else
				charCount.put(c,1);
			
		} 
		
		
	 
		for(char c:s)
			if(c!=' ')
			System.out.println(c+":"+charCount.get(c));
		 
		
		
	}

}
