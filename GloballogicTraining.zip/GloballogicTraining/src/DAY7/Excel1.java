package DAY7;

import java.util.ArrayList;

import DAY3.Student;


 

		public class Excel1 {

			public static void main(String[] args) {
				// TODO Auto-generated method stub
			   
			    
			  ArrayList<Student> student_al=new ArrayList<Student>();
			  ExcelFile1 ex=new ExcelFile1();
		
			  student_al=ex.read_excel(student_al);
			  student_al=ex.write_excel(student_al);
				 
			  
			  for(Student s:student_al)
				  s.display();

			}
		
		
		
		
		
		
		
	}


