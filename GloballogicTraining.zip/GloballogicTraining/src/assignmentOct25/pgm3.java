package assignmentOct25;

 

public class pgm3 {

	public static void main(String[] args) {
		
		int num[]= {23,44,84,37,91,18};
		int sum=0;
		int i;
		for(i=0;i<num.length;i=i+2)
			if(num[i]%2==1)
				sum+=num[i];
	
		System.out.println("Sum="+sum); 

	}

}
