package assignmentOct25;

public class ProdDetails {
	
	int pid,unit_purchased,price,rate_per_unit;
	String name,grade;
	
	public void calc()
	{
		price=unit_purchased*rate_per_unit;
		if(price<25000)
			grade="Grade A";
		else
			grade="Grade B";
		
	}

	public ProdDetails(int pid, String name, int rate_per_unit, int unit_purchased) {
		// TODO Auto-generated constructor stub
		
		this.pid=pid;
		this.name=name;
		this.rate_per_unit=rate_per_unit;
		this.unit_purchased=unit_purchased;
		calc();
		
		}
	
	

}
