package assignmentOct25;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

 

public class ExcelFile {
	
	
ArrayList<ProdDetails> Prod=new ArrayList<ProdDetails>();

		int pid,unit_purchased,price,rate_per_unit;
		String name,grade;
		

		int i; 
		
	public void read_excel()
			{
			 
			
	       try {
					
				    File f=new File("C:\\Users\\pratik.kumar2\\Desktop\\ProdDetails.xlsx");
					FileInputStream fis=new FileInputStream(f);
					@SuppressWarnings("resource")
					XSSFWorkbook wb=new XSSFWorkbook(fis);
					XSSFSheet sh=wb.getSheet("Sheet1");
					
					 
			 	  for(i=1;i<=3;i++) {
				    
			 		
			 		  
			 		  
                    XSSFRow r=sh.getRow(i);
					
					XSSFCell c0=r.getCell(0);
					pid=(int) c0.getNumericCellValue();
					
					XSSFCell c1=r.getCell(1);
					name=c1.getStringCellValue();
					
					XSSFCell c2=r.getCell(2);
					rate_per_unit=(int)c2.getNumericCellValue();
					
					XSSFCell c3=r.getCell(3);
					unit_purchased=(int)c3.getNumericCellValue();
					
					ProdDetails P=new ProdDetails(pid,name,rate_per_unit,unit_purchased);
					
					Prod.add(P);
					
					
					
					
			 	  }
			 	  
			 } 
				
				
			catch(FileNotFoundException e) {
				e.printStackTrace();
				}
				
				catch(IOException e) {
					e.printStackTrace();
				}
				
				 
				
			}
		 
		 
		 
		 
		 
		 
		 
		 
    public void write_excel()
			{
	             try {
					 
					File f=new File("C:\\Users\\pratik.kumar2\\Desktop\\ProdDetails.xlsx");
					FileInputStream fis=new FileInputStream(f);
					@SuppressWarnings("resource")
					XSSFWorkbook wb=new XSSFWorkbook(fis);
					XSSFSheet sh=wb.getSheet("Sheet1");
					int row=1;
				
					for(ProdDetails P:Prod) {
					
					XSSFRow r=sh.getRow(row);
					
					XSSFCell c4=r.createCell(4);
					c4.setCellValue(P.price);
					
					XSSFCell c5=r.createCell(5);
					c5.setCellValue(P.grade);
					
					//XSSFCell c2=r.createCell(2);
					//c2.setCellValue(t.from);
					
					 row++;
					
					 
					
					
					FileOutputStream fos=new FileOutputStream(f);
					wb.write(fos);
					 
					 
					 } }
	             
	             
			catch(FileNotFoundException e1) {
				e1.printStackTrace();
				}
				
				catch(IOException e) {
					e.printStackTrace();
				} 
				
			
			 
			
			}
			
			
			
			
			
			
	}









