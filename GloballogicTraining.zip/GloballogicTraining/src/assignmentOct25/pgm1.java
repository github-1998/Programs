package assignmentOct25;

import java.util.ArrayList;

public class pgm1 {

	public static void main(String[] args) {
		
		
		ArrayList<Integer> numbers=new ArrayList<Integer>();
		for(int i=10;i<=30;i++)
			if(i%2==0)
				numbers.add(i);
		
		for(Integer n:numbers)
			System.out.print(n+" ");

	}

}
