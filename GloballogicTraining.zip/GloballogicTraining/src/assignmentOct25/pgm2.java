package assignmentOct25;

import java.util.ArrayList;

public class pgm2 {
	
	public static int DigitCount(int num)
	{
		int count=0;
		while(num>0)
		{
			num=num/10;
			count++;
		}
		return count;
	}
	
	
	

public static int isAmstrong(int num)
	{
		int sum=0;
		int rem;
		int n=DigitCount(num);
		 
      while(num>0)
		{
			rem=num%10;
			sum+=Math.pow(rem,n);
			num=num/10;
		}
		
		 return sum;
		
	}


	
	
	
public static void main(String[] args) {
		int i;
		int count=0;
		ArrayList<Integer> numbers=new ArrayList<Integer>();
		
		
	for(i=1;;i++)
		{
			if(isAmstrong(i)==i) {
				
			      count++;
			      numbers.add(i);
				 
			}
		if(count==5)
			break;
		 
		}
	
	System.out.println("Amstrong Numbers are:");
	for(Integer num:numbers)
		System.out.print(num+" ");
	
}}

