package assignmentOct25;

 

class Student{
	
	int rollno;
	float java,selenium,avg;
	String name;
	
	public void average()
	{
		avg=(java+selenium)/2;
	}
	
	public Student(int rollno,String name,float java,float selenium) {
		this.rollno=rollno;
		this.java=java;
		this.selenium=selenium;
		this.name=name;
		average();
	}
	
	public void display()
	{
		System.out.println("Roll no:"+rollno);
		System.out.println("Java Marks:"+java);
		System.out.println("Selenium Marks:"+selenium);
		System.out.println("Name:"+name);
		System.out.println("Average:"+avg);
		
	}
}






public class pgm4 {
	
	public static void main(String[] args) {
		 
			 Student s1=new Student(101,"Ajay",90,80);
			 if(s1.avg>65)
				 s1.display();
		 
			 Student s2=new Student(102,"Vijay",40,80);
			 if(s2.avg>65)
				 s1.display();
			 
			 Student s3=new Student(103,"Ramesh",60,50);
			 if(s3.avg>65)
				 s1.display();
			 
		

	}

}
