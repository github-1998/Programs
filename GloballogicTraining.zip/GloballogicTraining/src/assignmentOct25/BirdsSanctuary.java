package assignmentOct25;



class Birds{
	
	String bodyColor,beakColor,bodyWt,eyeSize,bid;
	
	public void fly()
	{
		System.out.println("It can fly");
	}
	
	public void walk()
	{
		System.out.println("It can walk");
		
	}
	
	
	public void hunt()
	{
		System.out.println("It can hunt");
	}
	
	
	  
}


class Parrot extends Birds{
	
	public Parrot(String bodyColor,String beakColor,String bodyWt,String eyeSize,String bid)
	{
		this.bodyColor=bodyColor;
		this.beakColor=beakColor;
		this.bodyWt=bodyWt;
		this.eyeSize=eyeSize;
		this.bid=bid;
		 
	}
	
	public void properties(){
		
		System.out.println("BirdId:"+bid);
		System.out.println("Body Color:"+bodyColor);
		System.out.println("Beak Color:"+beakColor);
		System.out.println("Body Wt:"+bodyWt);
		System.out.println("Eyesize:"+eyeSize);
		
	}
	
	public void placesFound()
	{
		System.out.println("They are found in Austrailia , Central America and South America");
		
	}
	
	public void eatingHabits()
	{
		System.out.println("Eats fruit , buds ,nuts ,seeds and insects");
	}
	
	public void specialTalent()
	{
		System.out.println("Imitate human speech or sound");
	}
	
	 
}




class  Owl extends Birds{
	
	public Owl(String bodyColor,String beakColor,String bodyWt,String eyeSize, String bid )
	{
		this.bodyColor=bodyColor;
		this.beakColor=beakColor;
		this.bodyWt=bodyWt;
		this.eyeSize=eyeSize;
		this.bid=bid;
		 
	}
	
	public void properties(){
		System.out.println("BirdId:"+bid);
		System.out.println("Body Color:"+bodyColor);
		System.out.println("Beak Color:"+beakColor);
		System.out.println("Body Wt:"+bodyWt);
		System.out.println("Eyesize:"+eyeSize);
		
	}
	
	public void placesFound()
	{
		System.out.println("They are found in Austrailia , Central America and South America");
		
	}
	
	
	public void eatingHabits()
	{
		System.out.println("Eats fruit , buds ,nuts ,seeds and insects");
	}
	
	public void specialTalent()
	{
		System.out.println("Imitate human speech or sound");
	}
	
	
}
























public class BirdsSanctuary {
	
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Parrot P1=new Parrot("Green","Red","Light","Small","Parrot1");
		Parrot P2=new Parrot("Green","Red","Light","Small","Parrot2");
		Parrot P3=new Parrot("Green","Red","Light","Small","Parrot3");
		
		Owl O1=new Owl("White","BLack","Light","Small","Owl1");
		Owl O2=new Owl("Black","BLack","Light","Small","Owl2");
		 
		
		System.out.println("Details of 2 Owls");
		P1.properties();
		P1.fly();
		P1.walk();
		P1.hunt();
		P1.placesFound();
		P1.eatingHabits();
		P1.specialTalent();
		System.out.println("");
		
		P2.properties();
		P2.fly();
		P2.walk();
		P2.hunt();
		P2.placesFound();
		P2.eatingHabits();
		P2.specialTalent();
		System.out.println("");
		
		P3.properties();
		P3.fly();
		P3.walk();
		P3.hunt();
		P3.placesFound();
		P3.eatingHabits();
		P3.specialTalent();
		System.out.println("");
		
		
		System.out.println("\n\nDetails of 3 Parrots");
		O1.properties();
		O1.fly();
		O1.walk();
		O1.hunt();
		O1.placesFound();
		O1.eatingHabits();
		O1.specialTalent();
		System.out.println("");
		
		O2.properties();
		O2.fly();
		O2.walk();
		O2.hunt();
		O2.placesFound();
		O2.eatingHabits();
		O2.specialTalent();
		
		 
		
		
		
		
		
		
		
		
		
		

	}

}
