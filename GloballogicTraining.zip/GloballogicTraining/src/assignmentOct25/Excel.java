package assignmentOct25;

public class Excel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ExcelFile ex=new ExcelFile();
		ex.read_excel();
		ex.write_excel();
		

	}

}
