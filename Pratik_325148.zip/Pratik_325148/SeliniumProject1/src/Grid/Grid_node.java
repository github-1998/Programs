package Grid;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Grid_node {
WebDriver dr;
String autURL, nodeURL;

@BeforeClass
public void setup() throws MalformedURLException{
autURL="https://www.facebook.com";
nodeURL="http://172.16.29.137/wd/hub";
DesiredCapabilities cap=DesiredCapabilities.firefox();
cap.setBrowserName("firefox");
cap.setPlatform(Platform.WINDOWS);
//System.setProperty("webdriver.gecko.driver","geckodriver_v0.24.0.exe");
dr=new RemoteWebDriver(new URL(nodeURL),cap);
}

@Test
public void t1()
{
	dr.get(autURL);
}


}
