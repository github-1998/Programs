package SDAY9;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.common.io.FileBackedOutputStream;

public class DriverScript {
	
	
public String read_excel(int row,int col)
	{
	String cellValue = null;
	   

		try {
			File f=new File("C:\\Users\\pratik.kumar2\\Desktop\\registerdemo.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			
			 XSSFRow r=sh.getRow(row);
			 XSSFCell c=r.getCell(col);
			 cellValue =c.getStringCellValue();
			 
			
			}
			
		catch(Exception e) {
 			e.printStackTrace();
		 }
	
		
		return cellValue ;
	
	}
	
	

public void write_excel(int row,int col,String val)
{
	 

	try {
		File f=new File("C:\\Users\\pratik.kumar2\\Desktop\\registerdemo.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("sheet1");
		
		 XSSFRow r=sh.getRow(row);
		 XSSFCell c=r.createCell(col);
		c.setCellValue(val);
		
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		
		}
		
	catch(Exception e) {
			e.printStackTrace();
	 }
}



public void enter_txt(String xp,String data,ChromeDriver cd) {
			 cd.findElement(By.xpath(xp)).sendKeys(data);
		}
		
		
public void selectGender(String xp,ChromeDriver cd){
		cd.findElement(By.xpath(xp)).click();
		}
		

public void verify(String xp,String fromExcel,ChromeDriver cd,int row)
		{
			String fromWebsite =cd.findElement(By.xpath(xp)).getText();
		    System.out.println("From Website:"+fromWebsite);
		    System.out.println("From Excel:"+fromExcel);
			if(fromExcel.equals(fromWebsite))
		    	write_excel(row,6,"Pass");
		    else
		    	write_excel(row,6,"Fail");
		    	
		}
		
		
		public void clickBtn(String xp,ChromeDriver cd) {
			cd.findElement(By.xpath(xp)).click();
		}
		
		
		public void launchChrome(String url,ChromeDriver cd) {
 			cd.get(url);
		}
		
		
		
		
	 

	
	
	public static void main(String[] args) {
		String key,location,testData;
		
		 
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		 ChromeDriver cd=new ChromeDriver();
		 DriverScript ds=new DriverScript();
		 int r;
		
	for(r=1;r<=18;r++) {
			key= ds.read_excel(r,3);
			System.out.println("key:"+key);
			
			location=ds.read_excel(r,4);                            //*[@id="LastName"]
			System.out.println("location:"+location);
			
			testData= ds.read_excel(r,5);
			System.out.println("testData:"+testData);
			//System.out.println("\n\n");
			 
			switch(key)
			{
			
			case "launch_chrome" :ds.launchChrome(testData,cd);
			                      System.out.println("launch chrome");    
			                       break;
			
			case "click_btn"     :ds.clickBtn(location,cd); 
			                      System.out.println("click btn");   
                                  break;
			
			case "select_gender" :ds.selectGender(location,cd);    
			                      System.out.println("select gender");
                                  break;
			
			case "enter_text"    :ds.enter_txt(location,testData,cd); 
			                      System.out.println("enter text");
			                      break;                                   //*[@id="ConfirmPassword"]
			
			case "verify"        :ds.verify(location,testData,cd,r);       //*[@id="register-button"]
			                      System.out.println("verify");
			                      break;
			 
			 
			
			                    
			}
			System.out.println("\n\n");
		}
 	}

}
