package SDAY1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

 
public class web_driver1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");
		dr.findElement(By.id("email")).sendKeys("pratikumar1998@gmail.com");//any text can be entered in texbox using sendkeys
	    dr.findElement(By.id("pass")).sendKeys("pratik1998");
	    dr.findElement(By.id("loginbutton")).click();
 
	    WebElement wel=dr.findElement(By.id("day"));
	    Select sel=new Select(wel);
	    sel.selectByVisibleText("28");
	    
	    String title=dr.getTitle();
	    System.out.println("Title:"+title);
	    
	    java.util.List<WebElement> rb= dr.findElements(By.name("sex"));
	    ((WebElement)rb.get(0)).click();
	    
	    
	    String profileName=dr.findElement(By.id("")).getText();
	    String expectedProfileName="";
	    
	    if(profileName.compareTo(expectedProfileName)==0)
	    	System.out.println("Login Success");
	    
	    else
	    	System.out.println("Login Failure");
	    
	    
	    
		
	 
	

}}
