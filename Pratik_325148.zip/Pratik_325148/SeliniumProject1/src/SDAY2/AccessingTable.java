package SDAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AccessingTable {

	public static void main(String[] args) {
		 
		
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.w3schools.com/html/html_tables.asp");
		
		String s=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[5]/td[1] ")).getText();
		System.out.println(s);  //blackslash is put so as to supress functionality of the function
		
		
		
		int r=5,c=1;
		for(r=2;r<=7;r++)
		{
			
			for(c=1;c<=3;c++)
			{
			String w=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr["+r+"]/td["+c+"]")).getText();
			System.out.println(w);	
			}
			
		}
		
		
		
		
	}

}
