package SDAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

 
public class FacebookFeatures {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		WebDriver dr=new ChromeDriver();
		
		//to open a website
		dr.get("https://www.facebook.com");   
		
		//to enter data in textBox
		dr.findElement(By.id("email")).sendKeys("pratikumar1998@gmail.com");
	    dr.findElement(By.id("pass")).sendKeys("pratik1998");
	    
	    //to click a button
	    dr.findElement(By.id("loginbutton")).click();
	    
	   //to select a value from dropdown list
	    WebElement wel=dr.findElement(By.id("day"));   
	    Select sel=new Select(wel);
	    sel.selectByVisibleText("28");
	    
	    //to get title (present in top left)
	    String title=dr.getTitle();
	    System.out.println("Title:"+title);
	    
	    //to fetch multiple elements
	    java.util.List<WebElement> rb= dr.findElements(By.name("sex"));
	    ((WebElement)rb.get(0)).click();
	    
	    
	    String profileName=dr.findElement(By.id("")).getText();
	    String expectedProfileName="";
	    
	    if(profileName.compareTo(expectedProfileName)==0)
	    	System.out.println("Login Success");
	    
	    else
	    	System.out.println("Login Failure");
	    
	    
	    
		
	 
	

}}
