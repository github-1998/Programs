package SDAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Hashtable;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import com.google.common.io.FileBackedOutputStream;



public class DriverScript {
	static Hashtable<String,Integer>id_rowNo=new Hashtable<String,Integer>();
	static Hashtable<Integer,String>writeRow=new Hashtable<Integer,String>();
	static ChromeDriver cd;
    static String filename; 
    

static void executeWebElements(int startRow,int n,int row) {
		
        int r;
        String key,location,testData;
		
        for(r=startRow;r<=n;r++) {
		    key=read_excel_sheet1(r,3);
		    // System.out.println("key:"+key);
		
		    location=read_excel_sheet1(r,4);                            //*[@id="LastName"]
		    // System.out.println("location:"+location);
		
		    testData=read_excel_sheet1(r,5);
		    // System.out.println("testData:"+testData);
		    //System.out.println("\n\n");
		 
		switch(key)
		{
		
		case "launch_chrome" :launchChrome(testData);
		                      System.out.println("launch chrome");    
		                       break;
		
		case "click_btn"     :clickBtn(location); 
		                      System.out.println("click btn");   
                              break;
		
		case "select_gender" :selectGender(location);    
		                      System.out.println("select gender");
                              break;
		
		case "enter_text"    :enter_txt(location,testData); 
		                      System.out.println("enter text");
		                      break;                                   //*[@id="ConfirmPassword"]
		
		case "verify"        :verify(location,testData,row);               //*[@id="register-button"]
		                      System.out.println("verify");
		                      break;

	
		}}}
	
	

	
	

public static String read_excel_sheet1(int row,int col){
	 String cellValue=null;
	 
	try {
			File f=new File(filename);
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
 			XSSFRow r=sh.getRow(row);
			XSSFCell c=r.getCell(col);
			cellValue =c.getStringCellValue();
			 
			}
			
		catch(Exception e) {
 			e.printStackTrace();
		 }
	
		
		return cellValue ;
	
}
	
	
	
	
	
	
	
public static void read_excel_sheet2(int row)  
	{
	String tc_id,flag,sheetname;
	int n;
	flag=null;
	tc_id=null;
	n=0;
	   
       try {
			File f=new File(filename);
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
			
			XSSFRow r=sh.getRow(row);
			
		    XSSFCell c0=r.getCell(0);
			tc_id=c0.getStringCellValue();
			
		    XSSFCell c1=r.getCell(1);
			flag=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			n=(int)c2.getNumericCellValue();
			
			XSSFCell c3=r.getCell(3);
			sheetname=c3.getStringCellValue();
			 
			
			}
			
		
       
       catch(Exception e) {
 			e.printStackTrace();
		 }
	
		
        if(flag.equals("Y")) 
             executeWebElements(id_rowNo.get(tc_id),n,row);	
  
	}






public static void write_excel(int row,int col,String val)
{
	 

	try {
		File f=new File(filename);
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("sheet2");
		
		 XSSFRow r=sh.getRow(row);
		 XSSFCell c=r.createCell(col);
		c.setCellValue(val);
		
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		
		}
		
	catch(Exception e) {
			e.printStackTrace();
	 }
}





//Keyword functions
public static void enter_txt(String xp,String data) {
			 cd.findElement(By.xpath(xp)).sendKeys(data);
		}
		
		
public static void selectGender(String xp){
		cd.findElement(By.xpath(xp)).click();
		}
		

public static void verify(String xp,String fromExcel,int row)
		{
			String fromWebsite =cd.findElement(By.xpath(xp)).getText();
		    System.out.println("From Website:"+fromWebsite);
		    System.out.println("From Excel:"+fromExcel);
			if(fromExcel.equals(fromWebsite))
		    	write_excel(row,4,"Pass");
		    else
		    	write_excel(row,4,"Fail");
		    	
		}
		

public static void clickBtn(String xp) {
			cd.findElement(By.xpath(xp)).click();
		}
		
public static void launchChrome(String url) {
	       // System.out.println("url:"+url);
 			cd.get(url);
		}
		
		
		
		
	 

	
	
	public static void main(String[] args) {
		
		 
	   id_rowNo.put("TC_02",1);
	   id_rowNo.put("TC_05",11);
	   filename="C:\\Users\\pratik.kumar2\\Desktop\\registerdemo.xlsx";
	   System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
	   cd=new ChromeDriver();
	       
 		
	   
		int i;
		for(i=1;i<=2;i++) 
			read_excel_sheet2(i);
		
	}	
		
		
		
}	
		
		
		
		
		
		
		
		
		
	 
		
		
		
	 
 
