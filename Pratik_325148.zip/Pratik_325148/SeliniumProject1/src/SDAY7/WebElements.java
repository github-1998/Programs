package SDAY7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElements {

	WebDriver dr;
	public void all_webelement_fns1(WebDriver dr) {
		this.dr=dr;
	}
	
	
	public void enter_txt(String xp,String data) {
		System.out.println(xp+"" +data);
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}
	
	
	public void click(String  xp) {
		dr.findElement(By.xpath(xp)).click();
	}
	
	
	public void launchChrome(String url) {
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}
}



