package SDAY5;

import org.testng.annotations.Test;

public class TestAnnotation {
  
	
 @Test
   public void t1()
  {
	  System.out.println("in t1");
  }
  
  
  public void t2()
  {
	  System.out.println("in t2");
  }
  
  
  public void t3()
  {
	  System.out.println("in t3");
  }
  
  
  
  
}
