package SDAY5;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Assign_Annotation {
  
   @BeforeClass
  public void BC()
  {    System.out.println("I came to the cricket stadium");  }
  
  
  @Test
  public void t1()
  {
	  System.out.println("I met Mr Dhoni");
  }
  
  
  @Test
  public void t2()
  {
	  System.out.println("I had lunch with Mr Virat kohli");
  }
  
  
  
  
  
  @AfterMethod
  public void AM()
  {
	  System.out.println("Bye");
  }
  
  
  @BeforeMethod
  public void BM()
  {
	  System.out.println("Hello");
  }
  
  
  
  
  
  @Test
  public void t3()
  {
	  System.out.println("I took a pic withMr Rohit Sharma");
  }
  
  
  
  
  
  @AfterClass
  public void AF()
  {
	  System.out.println("Now I am back home");
  }
  
  
  
  
}
