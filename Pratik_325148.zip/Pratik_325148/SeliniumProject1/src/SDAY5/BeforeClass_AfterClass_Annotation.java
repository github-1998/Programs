package SDAY5;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class BeforeClass_AfterClass_Annotation {

	@BeforeClass
	public void BC()
	
	{
		System.out.println("BC");
	}
	
	
	@AfterClass
	public void AC()
	
	{
		System.out.println("BC");
	}
	
	
	
	public void c()
	{
		System.out.println("In test c");
	}
	
	
	
	@Test
	public void b()
	{
		
		System.out.println("In test b");
	}
	
	
	@Test
	public void a()
	{
		System.out.println("In test a");
	}
	
	
}
