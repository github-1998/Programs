package SDAY5;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class BeforeMethod_AfterMethod_Annotation {
	
	@AfterMethod
	public void AM()
	{
		System.out.println("After Method");
	}

	
	@BeforeMethod
	public void BM()
	{
		System.out.println("Before Method");
	}
	
	
	
	public void c()
	{
		System.out.println("c Method");
	}
	
	
	@Test
	public void b()
	{
		System.out.println("b Method");
	}
	
	
	@Test
	public void a()
	{
		System.out.println("a Method");
	}
	
	
	
}
