package SDAY3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MultipleHandles {

	public static void main(String[] args) {
		 
System.setProperty("webdriver.chrome.driver", "chromedriver_78.exe");
WebDriver dr=new ChromeDriver();
dr.get("https://www.naukri.com/");
for(String handle : dr.getWindowHandles())
{
	
dr.switchTo().window(handle);
String title=dr.getTitle();
System.out.println(title);
}

	}

}
