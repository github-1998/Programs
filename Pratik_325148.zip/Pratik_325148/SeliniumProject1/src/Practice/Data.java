package Practice;

public class Data {
	
	String uid,password,expResult,expErrorMsgFirst,expErrorMsgSecond;
	String actResult,actErrorMsgFirst,actErrorMsgSecond,testResult;
	
	public void displayRead()
	{
		System.out.println("uid:"+uid);
		System.out.println("password:"+password);
		System.out.println("Expected Result:"+expResult);
		System.out.println("Expected Error Msg First"+expErrorMsgFirst);
		System.out.println("Expected Error Msg Second"+expErrorMsgSecond);
		System.out.println("\n\n");
	}
	
	public void displayWrite()
	{
		System.out.println("Actual Result:"+actResult);
		System.out.println("Actual Error Msg First:"+actErrorMsgFirst);
		System.out.println("Actual Error Msg Second:"+actErrorMsgSecond);
		System.out.println("Test Result:"+testResult);
		System.out.println("\n\n");
		
	}
	

}
