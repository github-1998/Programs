package Practice;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class ExcelFile_Using_Annotation {

	ArrayList<Data> dataForReading=new ArrayList<Data>();
	ArrayList<Data> dataForWriting=new ArrayList<Data>();
	
	
   
	public void login()
	{
		for(Data d:dataForReading) {
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		ChromeDriver wd=new ChromeDriver();
	    wd.get("http://demowebshop.tricentis.com/login");
		wd.findElement(By.name("Email")).sendKeys(d.uid);
		wd.findElement(By.name("Password")).sendKeys(d.password);
		wd.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		boolean f=wd.getTitle().contains("Login");
		
		Data data=new Data();
		if(f)
		{
			data.actResult="FAILURE";
			data.actErrorMsgFirst=wd.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
			data.actErrorMsgSecond=wd.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
		
			if(d.expErrorMsgFirst.equals(data.actErrorMsgFirst) && d.expErrorMsgSecond.equals(data.actErrorMsgSecond))
				data.testResult="PASS";
			
			else
				data.testResult="FAILURE";
		}
		
		else {
			
			data.actResult="PASS";
			data.testResult="PASS";
		}
		
		dataForWriting.add(data);
	}
	
	}
	
	
	
	
public void readExcel()
	{
	
	
		
	try {
		File f=new File("C:\\Users\\pratik.kumar2\\Desktop\\seleniumTesting.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		for(int i=1;i<=4;i++)
		{
			
           Data d=new Data();			
			XSSFRow r=sh.getRow(i);
			
			XSSFCell c1=r.getCell(1);
			d.uid=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			d.password=c2.getStringCellValue();
			
			XSSFCell c3=r.getCell(3);
			d.expResult=c3.getStringCellValue();
			
			XSSFCell c4=r.getCell(4);
			d.expErrorMsgFirst=c4.getStringCellValue();
			
			XSSFCell c5=r.getCell(5);
			d.expErrorMsgSecond=c5.getStringCellValue();
			
			 dataForReading.add(d);
			 
		}
		wb.close();
	}
		catch(Exception e)
		{e.printStackTrace();}


	}

		
	


public void writeExcel()
{
	try {
		File f=new File("C:\\Users\\pratik.kumar2\\Desktop\\seleniumTesting.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		int row=1;
		for(Data d:dataForWriting) {
		
		XSSFRow r=sh.getRow(row);
		
		XSSFCell c6=r.createCell(6);
		c6.setCellValue(d.actResult);
		 
		
		XSSFCell c7=r.createCell(7);
		c7.setCellValue(d.actErrorMsgFirst);
		 
		
		XSSFCell c8=r.createCell(8);
		c8.setCellValue(d.actErrorMsgSecond);
		 
		
		
		XSSFCell c9=r.createCell(9);
		c9.setCellValue(d.testResult);
		 
		
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		
 
		
		row++;
		}
		
		wb.close();
		
}
		
	
catch(Exception e) {
		e.printStackTrace();
	}
	
	 
}



/*@BeforeClass
void t1()
{
	readExcel();
}



@Test
void t2()
{
	login();
}
	
	
@AfterClass
void t3()
{
	writeExcel();
}*/



public static void main(String[] args)
{
	
	ExcelFile_Using_Annotation e=new ExcelFile_Using_Annotation();
	e.readExcel();
	e.login();
    e.writeExcel();
    
  //  for(Data d:e.dataForReading);
    	//d.displayRead();
    
    //for(Data d:e.dataForWriting);
    	//d.displayWrite();
}


	


	
}



