package Practice;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
 
 
public class ExcelFile {
	
String uid,password,expResult,expErrorMsgFirst,expErrorMsgSecond;
String actResult,actErrorMsgFirst,actErrorMsgSecond,testResult;

public void login()
{
	System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
	ChromeDriver wd=new ChromeDriver();
    wd.get("http://demowebshop.tricentis.com/login");
	wd.findElement(By.name("Email")).sendKeys(uid);
	wd.findElement(By.name("Password")).sendKeys(password);
	wd.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	boolean f=wd.getTitle().contains("Login");
	if(f)  //if login does not happen
	{
		actResult="FAILURE";
		actErrorMsgFirst=wd.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
		actErrorMsgSecond=wd.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
	
		if(expErrorMsgFirst.equals(actErrorMsgFirst) && expErrorMsgSecond.equals(actErrorMsgSecond))
			testResult="PASS";
		
		else
			testResult="FAILURE";
	}
	
	else {   //if login happens
		
		actResult="PASS";
		testResult="PASS";
	}
}
	

public void writeExcel(int row)
{
	try {
		File f=new File("C:\\Users\\pratik.kumar2\\Desktop\\seleniumTesting.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		
		XSSFRow r=sh.getRow(row);
		
		XSSFCell c6=r.createCell(6);
		c6.setCellValue(actResult);
		//System.out.println(actResult);
		
		XSSFCell c7=r.createCell(7);
		c7.setCellValue(actErrorMsgFirst);
		//System.out.println(actErrorMsgFirst);
		
		XSSFCell c8=r.createCell(8);
		c8.setCellValue(actErrorMsgSecond);
		//System.out.println(actErrorMsgSecond);
		
		XSSFCell c9=r.createCell(9);
		c9.setCellValue(testResult);
		//System.out.println(testResult);
		
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		
}
		
	
catch(Exception e) {
		e.printStackTrace();
	}
	
	 
}



public void readExcel()
{
	
try {
	File f=new File("C:\\Users\\pratik.kumar2\\Desktop\\seleniumTesting.xlsx");
	FileInputStream fis=new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sh=wb.getSheet("Sheet1");
	for(int i=1;i<=4;i++)
	{
		XSSFRow r=sh.getRow(i);
		
		XSSFCell c1=r.getCell(1);
		uid=c1.getStringCellValue();
		
		XSSFCell c2=r.getCell(2);
		password=c2.getStringCellValue();
		
		XSSFCell c3=r.getCell(3);
		expResult=c3.getStringCellValue();
		
		XSSFCell c4=r.getCell(4);
		expErrorMsgFirst=c4.getStringCellValue();
		
		XSSFCell c5=r.getCell(5);
		expErrorMsgSecond=c5.getStringCellValue();
		
		login();
		writeExcel(i);
	}
	//wb.close();
}
	catch(Exception e)
	{e.printStackTrace();}


}


public static void main(String[] args)
{
	ExcelFile e=new ExcelFile();
	e.readExcel();
}



}
