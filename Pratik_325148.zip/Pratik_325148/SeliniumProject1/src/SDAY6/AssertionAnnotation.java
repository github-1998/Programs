package SDAY6;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class AssertionAnnotation {
	
	
	
	 @Test(priority=4)
	  public void c() {
		 String s1,s2;
		 s1="noida";
		 s2="noida";
		 Assert.assertEquals(s1,s2);
		 System.out.println("func c");
		  
	  }
	  
	  
	  @Test(priority=3)
	  public void b() {
		  
		  String s1,s2;
			 s1="noida";
			 s2="noida1";
			 
		 SoftAssert sa=new SoftAssert();
		 sa.assertEquals(s1,s2);
		  System.out.println("func b");
		  sa.assertAll();
		  
	  } 
	  
	  
	  
	  @Test(priority=0)
	  public void a() {
		   
		  System.out.println("func a");
		  
	  }
	  
	  
	  
	}


//}
