package SDAY6;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderConcept {
	
	public class NewTest2 {
		  
		@Test(dataProvider="security")              //extract data from the DataProvider whose name is security
		  public void login(String u, String p) {
		 System.out.println("Login: " +u+ " "+p);
		  }
		  
		  
		 @DataProvider(name="security")
		  public String[][] getdata() {
		 String [][]data= {{"uid1","233"},{"uid2","pwd2"}};
		 return data;
		  }
		
	}
	
	
	 
}