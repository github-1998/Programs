package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class PomAddToCart {
	
	static String s1;
	static String s2;
	
	
	@AfterClass
	public static void verify(String s1,String s2){
		 SoftAssert sa=new  SoftAssert();
		  sa.assertEquals(s1,s2);
		  sa.assertAll();
		  System.out.println("s1 "+s1+"             "+"s2 "+s2);
			System.out.println("Verified");
	}
	
	
	
	@BeforeClass
	private static void login(WebDriver dr) {
		dr.get("https://www.saucedemo.com/");
		dr.findElement(By.id("user-name")).sendKeys("standard_user");
	    dr.findElement(By.id("password")).sendKeys("secret_sauce");
 	    dr.findElement(By.xpath("//*[@id='login_button_container']/div/form/input[3]")).click();
	}
	
	
	@Test
	private static void addToCart(WebDriver dr){
		     dr.findElement(By.xpath("//*[@id='inventory_container']/div/div[1]/div[3]/button")).click();
		     s1=dr.findElement(By.xpath("//*[@id='item_4_title_link']/div")).getText();
		     dr.findElement(By.xpath("//span[@ class='fa-layers-counter shopping_cart_badge']")).click();
		     s2=dr.findElement(By.xpath("//*[@id='item_4_title_link']/div")).getText();
		}
 
	
	

	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		WebDriver dr=new ChromeDriver();
		login(dr);
		addToCart(dr);
	    verify(s1,s2);
	    	
	}


	
	
	
	  
}      

 
