package SDAY8;

import org.apache.log4j.Logger;

public class LogFile {

	public static void main(String[] args) {
		 
		Logger log=Logger.getLogger("devpinoyLogger");      //apache log4j
		log.debug("Error Happened");

	}

}
