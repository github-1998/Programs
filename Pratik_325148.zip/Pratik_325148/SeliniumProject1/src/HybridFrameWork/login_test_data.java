package HybridFrameWork;

public class login_test_data {
	public String uid,pwd;

}
