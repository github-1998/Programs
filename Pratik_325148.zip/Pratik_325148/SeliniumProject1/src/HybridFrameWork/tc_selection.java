package HybridFrameWork;

public class tc_selection {

	public String tcid,flag,no_steps,test_data_sh;
}
