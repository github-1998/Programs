package HybridFrameWork;

public class keyword_sh {
	public String TC_ID,step_no,keyWord,xPath,Test_Data;

}
