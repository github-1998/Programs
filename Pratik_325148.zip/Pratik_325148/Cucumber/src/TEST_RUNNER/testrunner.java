package TEST_RUNNER;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="FEATURES",
                 glue="STEP_DEF",
                 tags="@ROUND1",
                 plugin="html:Reports/cucumber_report")








public class testrunner extends AbstractTestNGCucumberTests{

}
