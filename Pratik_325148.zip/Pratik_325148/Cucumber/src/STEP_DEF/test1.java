package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	
	static WebDriver dr;
	
	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {
		System.out.println("Login page is displayed");
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		
		
		
 	}

	@When("^User enters login data and clicks on ok button$")
	public void user_enters_login_addta_and_clicks_on_ok_button() throws Throwable {
		System.out.println("user enters login data and presses enter");
		dr.findElement(By.name("Email")).sendKeys("pratikumar1998@gmail.com");
		dr.findElement(By.name("Password")).sendKeys("web1998");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		 
	     
	}

	@Then("^Home page is displayed$")
	public void home_page_is_displayed() throws Throwable {
		System.out.println("Home page is displayed");
		String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		System.out.println(s);
		SoftAssert sa =new SoftAssert();
		sa.assertEquals(s,"pratikumar1998@gmail.com");
		sa.assertAll();
		
		
	    
	}




}
