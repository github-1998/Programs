package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
	
	
	WebDriver dr;
	
	
	@When("^User enters invalid data and clicks on ok button$")
	public void user_enters_login_addta_and_clicks_on_ok_button() throws Throwable {
		System.out.println("user enters invalid data and clicks ok button");
		dr=test1.dr;
		dr.findElement(By.name("Email")).sendKeys("pratikumar1998@gmail.com");
		dr.findElement(By.name("Password")).sendKeys("web1998");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		 
	     
	}
	 
	@Then("^Home page not displayed$")
	public void home_page_not_displayed() throws Throwable {
		System.out.println("Home page is not displayed");
		String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		System.out.println(s);
		SoftAssert sa =new SoftAssert();
		sa.assertEquals(s,"pratmar1998@gmail.com"); //mismatch expected and actual result
		sa.assertAll();
		
		
	    
	}


	

}
